#!/bin/bash
while true; do
    python3 simulation_runner.py --ticks 9000 --retail 50
    sleep 1
done
