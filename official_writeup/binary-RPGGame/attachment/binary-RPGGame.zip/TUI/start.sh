#!/bin/bash
stty raw -echo
TERM=linux COLUMNS=600 LINES=45 /RPGGame3
