            !!! DoNex ransomware warning !!!

>>>> Your data are stolen and encrypted

	The data will be published on TOR website if you do not pay the ransom 

	Links for Tor Browser:
	http://[redacted].onion
	

>>>> What guarantees that we will not deceive you? 

	We are not a politically motivated group and we do not need anything other than your money. 
    
	If you pay, we will provide you the programs for decryption and we will delete your data. 
    
	If we do not give you decrypters, or we do not delete your data after payment, then nobody will pay us in the future. 
	
	Therefore to us our reputation is very important. We attack the companies worldwide and there is no dissatisfied victim after payment.
    

>>>> You need contact us and decrypt one file for free on these TOR sites with your personal DECRYPTION ID

	Download and install TOR Browser https://www.torproject.org/
	Write to a chat and wait for the answer, we will always answer you. 
	
	You can install qtox to contanct us online https://[redacted]/
	Tox ID Contact: [redacted]
	
	Mail (OnionMail) Support: [redacted]@onionmail.org
	
>>>> Warning! Do not DELETE or MODIFY any files, it can lead to recovery problems!

>>>> Warning! If you do not pay the ransom we will attack your company repeatedly again!
	
