import * as parser from '@babel/parser'
import traverse from '@babel/traverse'
import { Hono } from 'hono'
/* flag location: /flag */
Object.defineProperties(globalThis, Object.getOwnPropertyDescriptors(Math))
function checkSafetyRegex(code: string) {
  const whitelist = /^[a-zA-Z0-9_+\-*/%() ]+$/
  if (!whitelist.test(code)) {
    throw new Error('Bad Code')
  }
  const blacklist =
    /(eval|Function|__proto__|constructor|prototype|window|document|import|require|process|globalThis|self|global|this|module|exports|fetch|new|confirm|alert|prompt|%[0-9a-f]{2})/i
  if (blacklist.test(code)) {
    throw new Error('Bad Code')
  }
}
function checkSafeAST(code: string) {
  const ast = parser.parse(code, {
    sourceType: 'script'
  })
  traverse.default(ast, {
    enter(path) {
      if (path.isStringLiteral()) {
        throw new Error('Bad Code')
      }
      if (path.isThisExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isMemberExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isOptionalMemberExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isCallExpression()) {
        const callee = path.get('callee')
        if (callee.isMemberExpression() || callee.isOptionalMemberExpression()) {
          throw new Error('Bad Code')
        }
      }
      if (path.node.leadingComments || path.node.innerComments || path.node.trailingComments) {
        throw new Error('Bad Code')
      }
      if (path.isObjectExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isObjectPattern()) {
        throw new Error('Bad Code')
      }
      if (path.isArrayExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isArrayPattern()) {
        throw new Error('Bad Code')
      }
      if (path.isRestElement()) {
        throw new Error('Bad Code')
      }
      if (path.isSpreadElement()) {
        throw new Error('Bad Code')
      }
      if (path.isFunctionDeclaration()) {
        throw new Error('Bad Code')
      }
      if (path.isFunctionExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isArrowFunctionExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isClassDeclaration()) {
        throw new Error('Bad Code')
      }
      if (path.isClassExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isNewExpression()) {
        throw new Error('Bad Code')
      }
      if (path.isIdentifier({ name: 'eval' })) {
        throw new Error('Bad Code')
      }
      if (path.isIdentifier({ name: 'Function' })) {
        throw new Error('Bad Code')
      }
      if (path.isIdentifier()) {
        const name = path.node.name
        if (!(name in globalThis)) {
          throw new Error('Bad Code')
        }
      }
    }
  })
}
function checkSafe(code: string) {
  checkSafetyRegex(code)
  checkSafeAST(code)
}
const app = new Hono()
app.get('/', (c) => {
  /* <irrelevant code removed> */
})
app.post('/eval', async (c) => {
  const code = await c.req.text()
  console.group('Incoming request:')
  console.group('Code:')
  console.log(code)
  console.groupEnd()
  try {
    checkSafe(code)
    const result = eval(code)
    if (JSON.stringify(result)?.length > 64) {
      console.log('Result: too long')
      return c.json({ error: 'Result too long' }, 400)
    } else {
      console.log('Result:', result)
      return c.json({ result })
    }
  } catch (e) {
    console.log(e)
    return c.json({ error: '' + e }, 400)
  } finally {
    console.groupEnd()
  }
})
app.get('/source', async (c) => {
  /* <irrelevant code removed> */
})
Deno.serve(app.fetch)
